#!/bin/bash

cp -rpv ../llama.cpp/llama.h          ./examples/talk-llama/llama.h
cp -rpv ../llama.cpp/llama.cpp        ./examples/talk-llama/llama.cpp
cp -rpv ../llama.cpp/unicode.h        ./examples/talk-llama/unicode.h
cp -rpv ../llama.cpp/unicode.cpp      ./examples/talk-llama/unicode.cpp
cp -rpv ../llama.cpp/unicode-data.h   ./examples/talk-llama/unicode-data.h
cp -rpv ../llama.cpp/unicode-data.cpp ./examples/talk-llama/unicode-data.cpp
